<?php
/**
 * Created by JetBrains PhpStorm.
 * User: sergey
 * Date: 2/14/13
 * Time: 7:46 PM
 * To change this template use File | Settings | File Templates.
 */

// keep / in the end
define('LIBS', 'libs/');

// DB config
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'pj1');
define('DB_USER', 'root');
define('DB_PASS', '1');